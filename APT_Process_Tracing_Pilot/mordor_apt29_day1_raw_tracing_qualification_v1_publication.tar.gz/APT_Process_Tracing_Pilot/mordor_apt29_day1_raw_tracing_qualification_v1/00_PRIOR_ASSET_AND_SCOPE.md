# Prior assets and fixed scope

This run examines one controlled OTRF/Mordor APT29 Day 1 execution source. It does
not reinterpret DiagChain's derived chains as raw provenance ground truth.

Before this run, a local archive from the separate
`OTRF/detection-hackathon-apt29` repository was present at 13,944,972 bytes.
Its Git blob SHA1 is `c865bfe112719037c30cbf8c3543289b2b97a654`, which differs
from the requested Security-Datasets fixed-commit blob. It was inspected for
discovery only and **not used** for selection, tracing, or reference mapping.
An earlier local study under `Documents/mid-term/research3_active_provenance_r38h_20261010`
uses that different archive; its predictions and labels were not read.

The actual input was downloaded from the public official repository at commit
`d9d40ef123d2c87d5d3df28c96bcab4f0faccc87`. The archive Git blob SHA1
matches the fixed tree's `7352679a173ec0310f9d0ed587782545182dd394`.
The author plan `apt29.xlsx` and Day 1 README were acquired from the same
commit only after the B-only result had been frozen.

Execution stayed in this local directory. The research server was not accessed
or written. No VM, Docker, attack command, model, remote LLM, or GitHub push was
used. The frozen budget is in `02_PRE_REGISTERED_POI_AND_REFERENCE_CONTRACT.json`.

Source: [OTRF Security-Datasets fixed commit](https://github.com/OTRF/Security-Datasets/tree/d9d40ef123d2c87d5d3df28c96bcab4f0faccc87/datasets/compound/apt29).
