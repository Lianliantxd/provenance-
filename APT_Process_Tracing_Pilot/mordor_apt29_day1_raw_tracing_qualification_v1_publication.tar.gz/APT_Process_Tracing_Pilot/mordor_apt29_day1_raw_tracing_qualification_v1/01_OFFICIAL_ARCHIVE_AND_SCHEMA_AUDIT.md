# Official archive and schema audit

The fixed-commit archive is **13,944,973 bytes**, SHA256
`98a073140860560d70080ace9142961be4f64b4862bae892d62d0f254d0fdbe5`.
It is an ordinary ZIP with one unencrypted DEFLATE member:
`apt29_evals_day1_manual_2020-05-01225525.json` (compressed member
13,944,732 bytes; uncompressed 385,334,029 bytes; CRC32 `181204c3`).
The whole-member CRC check passed; no member was extracted or executed.
The uncompressed volume is 367.48 MiB, consistent with the README's rounded
`367M` size label. That label is **not** the ZIP download size.

The member is newline-delimited flat JSON, despite its `.json` suffix. It has
196,081 parseable records and zero JSON-line errors. Top-level fields include
`SourceName`, `Channel`, `EventID`, `Hostname`, `RecordNumber`, and
`UtcTime`; operation fields include `ProcessGuid`, `ParentProcessGuid`,
`CommandLine`, `DestinationIp`, and `TargetFilename` when applicable.
The raw `EventTime` strings carry no timezone and were not used to order
events. Parseable `UtcTime` values were treated as UTC.

One Sysmon Event ID 1 record, member line 186178 / RecordNumber 439712, has
no structured `UtcTime` or `ProcessGuid` keys although its free-text
`Message` contains these strings. The frozen structured-field parser excludes
that one record from process-instance joins; no Message-derived identity was
silently inserted into the frozen B-only result.

The official Day 1 README reports Event ID 1/3/11 counts of 433/2,771/1,605.
The fixed ZIP itself contains 447/1,229/1,649 Sysmon-channel records. These
are **not equal**; the README appears to describe a different count snapshot
or procedure, but the reason is not established here. All downstream counts
use the actual fixed ZIP.

The author plan XLSX is 25,051 bytes, SHA256
`053e70c6ba95eac481b370f8b1545ec3f1f00306c828634741a8c7399719c228`,
and Git blob SHA1 `e2b95dc306967a6a2d9af033cf1fe7c3ad155c13`.
The local Day 1 README's Git blob SHA1 is
`c67a01214faf8b7944c1b525672dd9397e4638fc`; both match the same fixed
repository commit. XLSX was read as ZIP/XML without macros or command execution.

See `outputs/archive_inventory.json` for machine-readable provenance.
