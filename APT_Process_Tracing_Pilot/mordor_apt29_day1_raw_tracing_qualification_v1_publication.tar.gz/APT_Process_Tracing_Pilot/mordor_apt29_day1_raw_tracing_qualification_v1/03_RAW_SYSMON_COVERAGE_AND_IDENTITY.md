# Raw Sysmon coverage and process identity

The full ZIP member yielded 196,081 valid JSON records. The Sysmon provider and
channel account for 143,884 records. Host counts across all providers are:
SCRANTON 131,119; NASHUA 29,056; NEWYORK 23,935; UTICA 11,971.
The parseable UTC range is 2020-05-02 02:55:23.551 through 03:28:17.683.
There are 143,883 records with a parseable `UtcTime`; 52,198 records lack
one, almost all from non-Sysmon sources. One Sysmon Event ID 1 is the exception
described in `01_OFFICIAL_ARCHIVE_AND_SCHEMA_AUDIT.md`.

Within the actual Sysmon channel: Event ID 1 ProcessCreate = **447**;
Event ID 3 NetworkConnect = **1,229**; Event ID 11 FileCreate = **1,649**.
Of these, 446/447 Event ID 1 records have a structured ProcessGuid and UTC
time; Event IDs 3 and 11 have complete structured ProcessGuid and UTC time
in this archive. The 446 structured Event ID 1 records yield **446 distinct
(host, ProcessGuid) instances**. Their child creation records contain 327
parent GUIDs whose own Event ID 1 creation was observed and 119 whose parent
creation was not observed. One Event ID 1 lacks a structured parent GUID.
No observed parent creation is later than its child; no same-host duplicate
child ProcessGuid was found.

Only Event ID 1 creates a process lineage edge. Event ID 3 and 11 are attached
operations of their process instance. Event ID 10 ProcessAccess and Event ID 8
CreateRemoteThread were counted in archive coverage but never turned into
parent-child edges. Common IPs, paths, names, and time proximity were not used
as causal links.

The B-only path has six observed process creation records and one referenced
but unobserved System parent. Its six child Event ID 1 records assert six
parent-child relations, of which five have both process creations in the
archive. It has eight attached Event ID 3/11 operations. Those counts describe
system process ancestry, not verified attack propagation.

The scan took 7.277 seconds wall time. macOS `ru_maxrss` for that process was
29,179,904 bytes; the end-of-run local working directory occupies roughly
16 MiB, below the 3 GiB cap. A separate read-only replay of 32 selected raw
records took 0.947 CPU seconds and 1.012 wall seconds. CPU usage of the
original full scan was not instrumented; it is not inferred from wall time.
No model calls or server writes occurred.

Detailed counts, schema examples, field coverage and replay timing are in
`outputs/event_type_and_host_counts.json` and
`outputs/raw_event_locator_audit.json`.
