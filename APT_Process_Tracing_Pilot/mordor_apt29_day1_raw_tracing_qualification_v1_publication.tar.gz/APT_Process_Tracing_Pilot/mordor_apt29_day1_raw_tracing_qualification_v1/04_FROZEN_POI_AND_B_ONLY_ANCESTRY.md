# Frozen POI and B-only ancestry

Frozen at 2026-10-10T10:31:27.988485+00:00 UTC, before author-plan and DiagChain label review.

Contract SHA256: `3fa0d04150a4b2ff4dc13dfe947af94418fd8434026e3e4a5d0b70b9e5bcbb7a`.
B-only result SHA256: `99db0107cac16be197a257e36738689660c0ddef20a38e8199bea7499b489378`.

B: ZIP member `apt29_evals_day1_manual_2020-05-01225525.json`, 1-based record 137249, RecordNumber 398025, canonical SHA256 `756a87096f9ee7a63e2ec6fddf5f98e31bcf3a36b162a27277083ef690e389cf`.

Host: SCRANTON.dmevals.local; UTC: 2020-05-02T03:19:22.650000+00:00; EventID 1; ProcessGuid `{47ab858c-e6ba-5eac-6b00-000000000500}`; command `taskhostw.exe SYSTEM`.

Rule-generated score 3: {'encoded_script': False, 'file_create_same_instance': True, 'nonloopback_network_same_instance': True}. This is not an authenticated malicious alert.

## Sensor ancestry, downstream to upstream

- depth 0: EID1 record 137249, RecordNumber 398025, `{47ab858c-e6ba-5eac-6b00-000000000500}`, `C:\Windows\System32\taskhostw.exe`; canonical SHA256 `756a87096f9ee7a63e2ec6fddf5f98e31bcf3a36b162a27277083ef690e389cf`.
- depth 1: EID1 record 129499, RecordNumber 394208, `{47ab858c-e6af-5eac-1800-000000000500}`, `C:\Windows\System32\svchost.exe`; canonical SHA256 `b050d562bd345438b20a7266a9262189a7d14d0d66e392d5551a182ec1454a72`.
- depth 2: EID1 record 128670, RecordNumber 393791, `{47ab858c-e6ad-5eac-0b00-000000000500}`, `C:\Windows\System32\services.exe`; canonical SHA256 `d6bdff435ed2190fc502c6c3ab5f1b1a37338c7c0589f10ac1d2a271ffa8ce11`.
- depth 3: EID1 record 128513, RecordNumber 393713, `{47ab858c-e6ad-5eac-0800-000000000500}`, `C:\Windows\System32\wininit.exe`; canonical SHA256 `ead70a41833cf334220dd9fe8ba65bf81b022bc9149ef3de49d10f43c259518a`.
- depth 4: EID1 record 128310, RecordNumber 393613, `{47ab858c-e6ad-5eac-0500-000000000500}`, `C:\Windows\System32\smss.exe`; canonical SHA256 `7dc4a65bafe02f94fdb761b2679762f1565e09e928e14333715edb5aa190f367`.
- depth 5: EID1 record 127148, RecordNumber 393035, `{47ab858c-e69e-5eac-0300-000000000500}`, `C:\Windows\System32\smss.exe`; canonical SHA256 `257bbcb847e2025f7182660a07b9af324a9fa2e234f82b15b198b891152f11a7`.
- depth 6: parent GUID `{47ab858c-e69e-5eac-0100-000000000500}` referenced but no parent creation event observed.

Terminal condition: `PARENT_REFERENCED_NOT_OBSERVED`. 6 child EID1 creation assertions; 5 parents have a creation event in this archive. 8 attached EID3/EID11 operations.

These are process lineage and same-instance operations, not verified attack propagation or a global initial-compromise root.
