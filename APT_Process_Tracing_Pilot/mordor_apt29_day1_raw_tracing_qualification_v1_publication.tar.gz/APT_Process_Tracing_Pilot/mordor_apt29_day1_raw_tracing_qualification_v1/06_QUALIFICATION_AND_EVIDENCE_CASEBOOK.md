# B-only qualification and evidence casebook

## Frozen seed and path

The contract was frozen at 2026-10-10 10:29:14 UTC, SHA256
`3fa0d04150a4b2ff4dc13dfe947af94418fd8434026e3e4a5d0b70b9e5bcbb7a`.
Its predeclared late-half rule selected the highest-scoring eligible Event ID
1 at ZIP member line **137249**, RecordNumber **398025**, UTC
2020-05-02 03:19:22.650, host SCRANTON. This is `taskhostw.exe SYSTEM`,
ProcessGuid `{47ab858c-e6ba-5eac-6b00-000000000500}`, canonical record
SHA256 `756a87096f9ee7a63e2ec6fddf5f98e31bcf3a36b162a27277083ef690e389cf`.
It scored 3 from a later same-instance nonloopback network connection (+2)
and FileCreate (+1); it did not contain an encoded-script command. This
offline scoring uses observations after the B event and therefore is not a
real-time alert rule. It is a **RULE_GENERATED_INVESTIGATION_SEED**, not an
independently confirmed attack event.

The B-only output was frozen before the plan was read, SHA256
`99db0107cac16be197a257e36738689660c0ddef20a38e8199bea7499b489378`.
The following are all on SCRANTON; numbers are 1-based ZIP member line
locators for original Sysmon Event ID 1 records, ordered from B upstream:

| Depth | Record | ProcessGuid suffix | Process image | Relationship to next upstream process |
|---:|---:|---|---|---|
| 0 | 137249 | `6b00-000000000500` | `taskhostw.exe` | child of Schedule `svchost.exe` |
| 1 | 129499 | `1800-000000000500` | Schedule `svchost.exe` | child of `services.exe` |
| 2 | 128670 | `0b00-000000000500` | `services.exe` | child of `wininit.exe` |
| 3 | 128513 | `0800-000000000500` | `wininit.exe` | child of `smss.exe` |
| 4 | 128310 | `0500-000000000500` | `smss.exe` | child of earlier `smss.exe` |
| 5 | 127148 | `0300-000000000500` | `smss.exe` | child of System GUID whose creation is not observed |

Each row's full GUID, RecordNumber, UTC time and canonical record hash is in
`04_FROZEN_POI_AND_B_ONLY_ANCESTRY.md` and `outputs/b_only_candidates.json`.
The child Event ID 1 at each row directly records its ParentProcessGuid. This
is `SENSOR_PROCESS_CREATE`; it is not a content-flow or attack-causality
assertion. The System ancestor is `PARENT_REFERENCED_NOT_OBSERVED`.

B's process had two Event ID 3 connections to `10.0.0.4` (records 159384,
159385) and two Event ID 11 WindowsAzure log file creations (160018,
160599), all *after* B's creation. Four more file creates belong to ancestors.
Those are `SENSOR_NETWORK_CONNECT` / `SENSOR_FILE_CREATE` and
`OBSERVED_SAME_PROCESS_CONTEXT` only. They do not show payload propagation.

## Independent plan mapping and post-freeze comparison

The fixed-commit author XLSX was read only after the path freeze. All 31
Day 1 rows were mapped in `05_INDEPENDENT_AUTHOR_PLAN_RAW_MAPPING.csv`:
10 narrow raw-operation matches, 3 ambiguous multi-candidate matches,
13 with no distinctive scoped EID1/3/11 match, and 5 setup/plan-only rows.
The final mapping SHA256, frozen at 2026-10-10 10:35:05 UTC, is
`c285bf1968f4a00171db36a30d022edcb4ff738d3246194caceb6e6a1fd0e86b`.
An initial overbroad marker mapping was tightened *before* comparison; its
superseded digest and rationale are in the execution log. The reference
mapper reads the XLSX and raw-operation index, never the B-only result.
However, the same researcher had already seen the frozen B path before
writing the manual row-marker specifications. That makes this an
**artifact-separated but not fully reviewer-blinded** reference exercise;
the procedural leakage risk must be retained even though no overlap was
found.

Examples of narrow raw matches before B include plan 1.A's distinctive
payload process (record 373), 2.A's archive creation (2462), 3.A's image-file
creation (3610), 6.A's named executable launch (52209), and 10.A's named
service process launch (132298). These corroborate specific logged operations,
not every claim in a multi-action planned step. The plan does not provide
EventRecordID/ProcessGuid-level independent causal edge truth.

**None of the mapped attack-operation process instances is on B's ancestor
path.** In particular, `javamtsup.exe` at record 132298 is a child of
`services.exe`, while B's `taskhostw.exe` is a child of Schedule
`svchost.exe`. They share a system ancestor but are siblings in separate
branches; the service launch cannot be promoted to a cause of B. Shared host,
time window, or ancestor alone would be a `POTENTIAL_DEPENDENCY`, not a
sensor-supported attack path. No earliest documented attack source candidate
R can be named for this frozen B.

## Five qualification gates

| Gate | Result | Evidence |
|---|---|---|
| Q1 unique raw late B, no GT selection | Partial | Unique raw event and frozen rule; attack identity unconfirmed, offline score looks ahead |
| Q2 two non-input upstream attack activities | Partial | Several specific plan-to-raw operation matches predate B; the plan is not execution-level causal GT |
| Q3 attack-related cross-process creation | Fail | Real system ancestry exists, but no matched attack operation process is on it |
| Q4 legal attack upstream path | Fail | Sensor-supported lineage ends in system processes, not in mapped attack activities |
| Q5 full background and independent references | Partial | 196,081 full records and no GT used in B-only search; the reference mapper is code-separated, but its human author was not blind to the path |

All 32 distinct selected record references across path and mapping were
re-read from the original ZIP and their canonical SHA256 values matched.
`CausalEdgePrecision`, `CausalEdgeRecall`, and `CausalEdgeF1` are **NA**:
no independent content-propagation edge reference was established.
