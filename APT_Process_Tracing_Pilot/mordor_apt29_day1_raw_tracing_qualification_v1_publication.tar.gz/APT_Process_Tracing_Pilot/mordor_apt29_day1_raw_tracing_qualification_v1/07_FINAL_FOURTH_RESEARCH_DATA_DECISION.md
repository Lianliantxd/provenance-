# Final data qualification decision

**Data status: `RAW_TRACING_PARTIAL`. Method status:
`METHOD_GAP_NOT_TESTED`.**

The fixed official archive was safely obtained and fully parsed. The frozen
rule produced one verifiable late raw event B, and Sysmon Event ID 1 provides
a real multi-process ancestry for it. The qualification target nevertheless
fails: B is a generic `taskhostw.exe` investigation seed, not a confirmed
attack endpoint, and none of the independently mapped attack operations lies
on its ancestor path. A common `services.exe` ancestor does not establish
an attack dependency. Thus this case cannot yet support an evaluable
attack-source recovery score or an `EARLIEST_DOCUMENTED_ATTACK_SOURCE_CANDIDATE`.

Primary failure attribution: `B_NOT_ATTACK_CONFIRMED` and no
`SENSOR_PROCESS_CREATE` path from a mapped attack operation to B. The
unobserved System parent is `PROCESS_INSTANCE_UNRESOLVED` at the path end;
it is not evidence of the attacker. The score's use of later same-process
operations is a temporal-lookahead limitation, disclosed rather than
silently treated as an online alert. There was no search truncation:
the 12-hop and 256-event budgets were not reached. The published author
plan's attack-step order is not causal edge ground truth. The reference
mapping code did not read B-only output, but the researcher who wrote its
manual matching markers had already inspected that output. This is a
`LABEL_LEAKAGE_RISK` for strict blinded reference construction, not
evidence that the prediction itself read the plan.

No B-only method comparison, model, LLM call, or new algorithm was run.
No causal-edge P/R/F1 or improvement can be reported. The result neither
proves that the underlying simulation cannot support tracing with a
different *prospectively registered* investigation seed, nor establishes
that a fourth doctoral contribution has a method gap.

**One next action:** obtain an independently specified, execution-verified
late attack alert or raw event in a separate eligible source unit, then
preregister that unit's B-only evaluation before viewing its attack plan.
Do not replace this run's B after seeing the negative result.
