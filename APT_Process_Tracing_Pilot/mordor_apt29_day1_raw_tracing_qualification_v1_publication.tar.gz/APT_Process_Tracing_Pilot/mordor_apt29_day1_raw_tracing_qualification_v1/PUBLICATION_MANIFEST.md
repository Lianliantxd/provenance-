# Mordor APT29 Day 1 qualification: synchronization manifest

Publish only this run's original reports, frozen contracts, audit code, tests,
and derived aggregates. The official input is pinned to OTRF Security-Datasets
commit `d9d40ef123d2c87d5d3df28c96bcab4f0faccc87` and archive SHA256
`98a073140860560d70080ace9142961be4f64b4862bae892d62d0f254d0fdbe5`.
The decision is `RAW_TRACING_PARTIAL / METHOD_GAP_NOT_TESTED`.

The publication set is exactly the paths listed in
`PUBLICATION_SHA256SUMS.txt`. That checksum file excludes itself.

Do not sync `inputs/apt29_evals_day1_manual.zip` (raw host logs),
`inputs/apt29.xlsx` (author plan containing credential-like strings),
`inputs/day1_README.md` (third-party source copy),
`outputs/events.sqlite` (raw command lines and local index),
`outputs/archive_inventory.json` (absolute local path), or
`outputs/SHA256SUMS.txt` (checksums for excluded inputs).
Obtain public official inputs from the pinned source if reproducing.

The B-only JSON contains only the bounded selected process ancestry and its
attached operations. It is a negative qualification result, not a scored
attack-source benchmark. Publication does not change the frozen files or
permit retrospective B selection.
