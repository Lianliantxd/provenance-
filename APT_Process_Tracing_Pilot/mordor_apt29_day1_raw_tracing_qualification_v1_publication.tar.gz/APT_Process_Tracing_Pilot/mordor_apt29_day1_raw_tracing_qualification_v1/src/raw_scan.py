"""Bounded, label-blind Sysmon scan and single-POI ancestry extraction."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
from pathlib import Path
import re
import resource
import sqlite3
import time
import zipfile


ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "02_PRE_REGISTERED_POI_AND_REFERENCE_CONTRACT.json"
EXPECTED_CONTRACT_SHA = "3fa0d04150a4b2ff4dc13dfe947af94418fd8434026e3e4a5d0b70b9e5bcbb7a"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha(record: dict) -> str:
    raw = json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def parse_utc(value: object) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        dt = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="microseconds")


def nonloopback_ip(value: object) -> bool:
    if not isinstance(value, str):
        return False
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return False
    return not (ip.is_loopback or ip.is_unspecified or ip.is_link_local)


def field(record: dict, *names: str) -> str | None:
    for name in names:
        value = record.get(name)
        if value is not None and value != "":
            return str(value)
    return None


def event_row(record: dict, index: int, member: str) -> tuple:
    event_id = int(record["EventID"])
    return (
        index,
        event_id,
        parse_utc(record.get("UtcTime")),
        field(record, "Hostname", "Computer"),
        field(record, "ProcessGuid", "ProcessGUID"),
        field(record, "ParentProcessGuid", "ParentProcessGUID"),
        field(record, "Image"),
        field(record, "ParentImage"),
        field(record, "CommandLine"),
        field(record, "ParentCommandLine"),
        field(record, "DestinationIp"),
        field(record, "DestinationPort"),
        field(record, "TargetFilename"),
        field(record, "RecordNumber", "EventRecordID"),
        field(record, "SourceName"),
        field(record, "Channel"),
        canonical_sha(record),
        member,
    )


def init_db(db: sqlite3.Connection) -> None:
    db.execute("""CREATE TABLE events (
        idx INTEGER PRIMARY KEY, eid INTEGER, ts TEXT, host TEXT, guid TEXT,
        parent_guid TEXT, image TEXT, parent_image TEXT, command TEXT,
        parent_command TEXT, destination_ip TEXT, destination_port TEXT,
        target_file TEXT, record_number TEXT, provider TEXT, channel TEXT,
        canonical_sha256 TEXT, zip_member TEXT
    )""")
    db.execute("CREATE INDEX event_guid ON events(host,guid,eid)")
    db.execute("CREATE INDEX event_host_ts ON events(host,ts)")


def archive_guard(path: Path, contract: dict) -> tuple[zipfile.ZipFile, zipfile.ZipInfo]:
    if sha256_file(path) != contract["raw_archive_sha256"]:
        raise ValueError("archive SHA256 differs from frozen contract")
    zf = zipfile.ZipFile(path)
    members = zf.infolist()
    if len(members) != 1:
        raise ValueError("unexpected ZIP member count")
    item = members[0]
    if (
        item.filename != contract["zip_member"]
        or item.flag_bits & 1
        or item.file_size > 768 * 1024 * 1024
        or item.file_size < 1
        or item.filename.startswith("/")
        or ".." in Path(item.filename).parts
    ):
        raise ValueError("unsafe or mismatched ZIP member")
    return zf, item


def scan(path: Path, contract: dict) -> tuple[dict, sqlite3.Connection]:
    start = time.monotonic()
    zf, item = archive_guard(path, contract)
    db_path = ROOT / "outputs/events.sqlite"
    if db_path.exists():
        db_path.unlink()
    db = sqlite3.connect(db_path)
    db.row_factory = sqlite3.Row
    init_db(db)
    counts: Counter[str] = Counter()
    provider_counts: Counter[str] = Counter()
    channel_counts: Counter[str] = Counter()
    host_counts: Counter[str] = Counter()
    event_id_counts: Counter[str] = Counter()
    field_coverage: Counter[str] = Counter()
    errors: Counter[str] = Counter()
    min_time: str | None = None
    max_time: str | None = None
    examples: dict[str, dict] = {}
    with zf, zf.open(item) as stream:
        for index, raw in enumerate(stream, 1):
            counts["lines"] += 1
            try:
                record = json.loads(raw)
                if not isinstance(record, dict):
                    raise ValueError("not object")
                event_id = int(record["EventID"])
            except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                errors[type(exc).__name__] += 1
                continue
            counts["valid_json_events"] += 1
            host = field(record, "Hostname", "Computer") or "MISSING"
            provider = field(record, "SourceName") or "MISSING"
            channel = field(record, "Channel") or "MISSING"
            host_counts[host] += 1
            provider_counts[provider] += 1
            channel_counts[channel] += 1
            event_id_counts[str(event_id)] += 1
            for key in ("UtcTime", "Hostname", "ProcessGuid", "ParentProcessGuid",
                        "RecordNumber", "Image", "CommandLine", "DestinationIp",
                        "TargetFilename"):
                if record.get(key) not in (None, ""):
                    field_coverage[key] += 1
            ts = parse_utc(record.get("UtcTime"))
            if ts:
                counts["valid_utc_time"] += 1
                min_time = min(min_time, ts) if min_time else ts
                max_time = max(max_time, ts) if max_time else ts
            else:
                counts["missing_or_invalid_utc_time"] += 1
            is_sysmon = (
                provider == "Microsoft-Windows-Sysmon"
                and channel == "Microsoft-Windows-Sysmon/Operational"
            )
            if is_sysmon:
                counts["sysmon_events"] += 1
                counts[f"sysmon_event_{event_id}"] += 1
            if is_sysmon and event_id in (1, 3, 11):
                db.execute("INSERT INTO events VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                           event_row(record, index, item.filename))
                if str(event_id) not in examples:
                    examples[str(event_id)] = {
                        "record_index": index, "keys": sorted(record),
                        "host": host, "provider": provider, "channel": channel,
                    }
            if index % 10000 == 0:
                db.commit()
    db.commit()
    summary = {
        "archive_sha256": contract["raw_archive_sha256"],
        "zip_member": item.filename,
        "zip_crc32": f"{item.CRC:08x}",
        "zip_member_uncompressed_bytes": item.file_size,
        "counts": dict(counts), "parse_errors": dict(errors),
        "provider_counts": dict(provider_counts), "channel_counts": dict(channel_counts),
        "host_counts": dict(host_counts), "event_id_counts": dict(event_id_counts),
        "field_coverage": dict(field_coverage),
        "time_min_utc": min_time, "time_max_utc": max_time,
        "schema_examples": examples,
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "max_rss_raw_platform_units": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    }
    return summary, db


def row_dict(row: sqlite3.Row) -> dict:
    return dict(row)


def select_b(db: sqlite3.Connection, summary: dict, contract: dict) -> dict | None:
    min_t = datetime.fromisoformat(summary["time_min_utc"])
    max_t = datetime.fromisoformat(summary["time_max_utc"])
    midpoint = min_t + (max_t - min_t) / 2
    regex = re.compile(contract["predefined_generic_alert_rules"]["encoded_script_command_regex"])
    network = set()
    files = set()
    for row in db.execute("SELECT host,guid,destination_ip FROM events WHERE eid=3"):
        if row["host"] and row["guid"] and nonloopback_ip(row["destination_ip"]):
            network.add((row["host"], row["guid"]))
    for row in db.execute("SELECT host,guid FROM events WHERE eid=11"):
        if row["host"] and row["guid"]:
            files.add((row["host"], row["guid"]))
    eligible = []
    for row in db.execute("SELECT * FROM events WHERE eid=1 AND ts IS NOT NULL AND host IS NOT NULL AND guid IS NOT NULL"):
        if datetime.fromisoformat(row["ts"]) < midpoint:
            continue
        key = (row["host"], row["guid"])
        script = bool(regex.search(row["command"] or ""))
        net = key in network
        file_create = key in files
        score = 3 * script + 2 * net + int(file_create)
        if score >= contract["predefined_generic_alert_rules"]["minimum_alert_score"]:
            eligible.append((score, row["ts"], row["zip_member"], row["idx"],
                             script, net, file_create, row_dict(row)))
    eligible.sort(key=lambda x: (-x[0], -datetime.fromisoformat(x[1]).timestamp(), x[2], x[3]))
    summary["late_midpoint_utc"] = midpoint.isoformat(timespec="microseconds")
    summary["eligible_poi_count"] = len(eligible)
    if not eligible:
        return None
    score, _, _, _, script, net, file_create, selected = eligible[0]
    selected["selection_score"] = score
    selected["selection_features"] = {
        "encoded_script": script,
        "nonloopback_network_same_instance": net,
        "file_create_same_instance": file_create,
    }
    selected["seed_type"] = "RULE_GENERATED_INVESTIGATION_SEED"
    selected["archive_sha256"] = contract["raw_archive_sha256"]
    return selected


def ancestry(db: sqlite3.Connection, b: dict, contract: dict) -> dict:
    processes = []
    edges = []
    operations = []
    seen: set[tuple[str, str]] = set()
    host, guid = b["host"], b["guid"]
    stop = "MAX_DEPTH"
    for depth in range(contract["max_ancestor_depth"] + 1):
        if (host, guid) in seen:
            stop = "CYCLE"
            break
        seen.add((host, guid))
        creation = db.execute(
            "SELECT * FROM events WHERE eid=1 AND host=? AND guid=? ORDER BY ts,idx LIMIT 1",
            (host, guid)).fetchone()
        if creation is None:
            stop = "PARENT_REFERENCED_NOT_OBSERVED"
            processes.append({"host": host, "guid": guid, "creation_observed": False,
                              "depth": depth})
            break
        proc = row_dict(creation)
        proc["depth"] = depth
        proc["creation_observed"] = True
        processes.append(proc)
        for op in db.execute(
            "SELECT * FROM events WHERE eid IN (3,11) AND host=? AND guid=? ORDER BY ts,idx",
            (host, guid)):
            if len(operations) + len(processes) >= contract["max_unique_events"]:
                stop = "MAX_UNIQUE_EVENTS"
                break
            operations.append(row_dict(op))
        if stop == "MAX_UNIQUE_EVENTS":
            break
        parent = proc["parent_guid"]
        if not parent:
            stop = "PARENT_GUID_MISSING"
            break
        if parent == guid:
            stop = "SELF_PARENT_GUID"
            break
        parent_event = db.execute(
            "SELECT * FROM events WHERE eid=1 AND host=? AND guid=? ORDER BY ts,idx LIMIT 1",
            (host, parent)).fetchone()
        relation = {
            "host": host, "parent_guid": parent, "child_guid": guid,
            "child_eid1_record_index": proc["idx"],
            "child_eid1_canonical_sha256": proc["canonical_sha256"],
            "grade": "SENSOR_PROCESS_CREATE",
            "parent_creation_observed": parent_event is not None,
            "time_consistent": parent_event is None or (parent_event["ts"] and proc["ts"] and parent_event["ts"] <= proc["ts"]),
        }
        edges.append(relation)
        if parent_event is not None and not relation["time_consistent"]:
            stop = "PARENT_TIME_CONFLICT"
            break
        guid = parent
    return {
        "seed": b, "processes_downstream_to_upstream": processes,
        "creation_edges": edges, "same_instance_operations": operations,
        "terminal_condition": stop, "unique_process_instances": len(seen),
        "observed_parent_creations": sum(e["parent_creation_observed"] for e in edges),
        "max_ancestor_depth": contract["max_ancestor_depth"],
        "max_unique_events": contract["max_unique_events"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, default=ROOT / "inputs/apt29_evals_day1_manual.zip")
    args = parser.parse_args()
    if sha256_file(CONTRACT) != EXPECTED_CONTRACT_SHA:
        raise ValueError("POI contract changed after freeze")
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    summary, db = scan(args.archive, contract)
    b = select_b(db, summary, contract)
    (ROOT / "outputs/event_type_and_host_counts.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    locator = {
        "locator_policy": "1-based line index in one JSONL ZIP member; canonical hash is SHA256 of sorted compact UTF-8 JSON",
        "archive_sha256": contract["raw_archive_sha256"],
        "selected_b_locator": None if b is None else {
            "zip_member": b["zip_member"], "record_index": b["idx"],
            "canonical_record_sha256": b["canonical_sha256"],
            "record_number": b["record_number"],
        },
    }
    (ROOT / "outputs/raw_event_locator_audit.json").write_text(
        json.dumps(locator, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if b is not None:
        result = ancestry(db, b, contract)
        out = ROOT / "outputs/b_only_candidates.json"
        out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (ROOT / "outputs/b_only_candidates_sha256.txt").write_text(
            sha256_file(out) + "  b_only_candidates.json\n")
    print(json.dumps({
        "total": summary["counts"]["valid_json_events"],
        "event_id_counts": {k: summary["event_id_counts"].get(k, 0) for k in ("1", "3", "11")},
        "eligible_poi_count": summary["eligible_poi_count"],
        "b_record_index": None if b is None else b["idx"],
        "b_score": None if b is None else b["selection_score"],
    }))
    db.close()


if __name__ == "__main__":
    main()
