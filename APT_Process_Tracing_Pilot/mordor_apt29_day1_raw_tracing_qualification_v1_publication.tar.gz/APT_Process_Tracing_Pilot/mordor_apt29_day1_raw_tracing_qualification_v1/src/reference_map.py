"""Independent author-plan-to-raw-operation mapping; never reads B-only output."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parents[1]
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}

# Exact, publicly visible plan markers. A match corroborates only the named
# raw operation, not every claim within a multi-action plan step.
SPECS: dict[int, tuple[int, str, str, str]] = {
    5: (1, "image", "3aka3", "SCRANTON"),
    7: (11, "target_file", "Draft.Zip", "SCRANTON"),
    11: (11, "target_file", "monkey.png", "SCRANTON"),
    12: (1, "command", "monkey.png", "SCRANTON"),
    14: (11, "target_file", "SysinternalsSuite.zip", "SCRANTON"),
    15: (1, "command", "3aka3", "SCRANTON"),
    19: (1, "image", "accesschk.exe", "SCRANTON"),
    26: (11, "target_file", "python.exe", "NASHUA"),
    27: (1, "image", "PsExec64.exe", "SCRANTON"),
    28: (11, "target_file", "Rar.exe", "NASHUA"),
    29: (11, "target_file", "working.zip", "NASHUA"),
    30: (1, "command", "working.zip", "NASHUA"),
    31: (1, "image", "javamtsup.exe", "SCRANTON"),
}


def workbook_rows(path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(path) as zf:
        shared_root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
        strings = [
            "".join(part.text or "" for part in si.findall(".//m:t", NS))
            for si in shared_root.findall("m:si", NS)
        ]
        sheet = ET.fromstring(zf.read("xl/worksheets/sheet1.xml"))
    rows = []
    for row in sheet.findall(".//m:sheetData/m:row", NS):
        values: dict[str, str] = {}
        for cell in row.findall("m:c", NS):
            key = re.match(r"[A-Z]+", cell.attrib["r"])
            value = cell.find("m:v", NS)
            if key is None or value is None or value.text is None:
                continue
            values[key.group()] = (
                strings[int(value.text)] if cell.attrib.get("t") == "s" else value.text
            )
        values["source_row"] = row.attrib["r"]
        rows.append(values)
    return rows


def raw_refs(db: sqlite3.Connection, spec: tuple[int, str, str, str], row_number: int) -> list[dict]:
    eid, field, token, host = spec
    assert field in {"image", "command", "target_file"}
    rows = db.execute(
        f"SELECT idx,eid,host,ts,guid,canonical_sha256,record_number,zip_member "
        f"FROM events WHERE eid=? AND host LIKE ? AND lower({field}) LIKE ? ORDER BY idx",
        (eid, host + ".%", "%" + token.lower() + "%"),
    ).fetchall()
    matches = [dict(row) for row in rows]
    if row_number in (26, 28):
        exact_path = "c:\\windows\\temp\\" + ("python.exe" if row_number == 26 else "rar.exe")
        matches = [
            match for match in matches
            if (db.execute("SELECT target_file FROM events WHERE idx=?", (match["idx"],))
                .fetchone()["target_file"] or "").lower() == exact_path
        ]
    if row_number in (15, 30):
        matches = [
            match for match in matches
            if "sdelete64.exe" in (
                db.execute("SELECT image FROM events WHERE idx=?", (match["idx"],))
                .fetchone()["image"] or "").lower()
        ]
    return matches


def main() -> None:
    xlsx = ROOT / "inputs/apt29.xlsx"
    db = sqlite3.connect(ROOT / "outputs/events.sqlite")
    db.row_factory = sqlite3.Row
    rows = workbook_rows(xlsx)
    output = ROOT / "05_INDEPENDENT_AUTHOR_PLAN_RAW_MAPPING.csv"
    fields = [
        "source_row", "report_step", "stage", "status", "raw_record_refs",
        "host", "process_guid", "event_type", "time", "ambiguity",
        "mapping_basis", "review_comment",
    ]
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows[1:]:
            number = int(row["source_row"])
            step = (row.get("C") or "").strip()
            stage = (row.get("A") or "").strip()
            spec = SPECS.get(number)
            matches = [] if spec is None else raw_refs(db, spec, number)
            if step == "0":
                status = "PLANNED_ONLY"
                comment = "Setup instruction; no claimed target operation evaluated."
            elif spec is None:
                status = "RAW_NOT_OBSERVED"
                comment = "No distinctive EID1/EID3/EID11 operation marker under frozen matching scope."
            elif not matches:
                status = "RAW_NOT_OBSERVED"
                comment = "Distinctive plan marker absent from scoped raw operations."
            elif len(matches) > 1:
                status = "RAW_AMBIGUOUS"
                comment = "All matching operations retained; row-to-operation identity is not unique."
            else:
                status = "RAW_OPERATION_MATCHED"
                comment = "Specific raw operation corroborates only this narrow action, not the full plan step or causality."
            writer.writerow({
                "source_row": number,
                "report_step": step,
                "stage": stage,
                "status": status,
                "raw_record_refs": json.dumps(matches, ensure_ascii=False, separators=(",", ":")),
                "host": "" if not matches else ";".join(sorted({m["host"] for m in matches})),
                "process_guid": "" if not matches else ";".join(sorted({m["guid"] or "" for m in matches})),
                "event_type": "" if spec is None else spec[0],
                "time": "" if not matches else ";".join(m["ts"] or "" for m in matches),
                "ambiguity": "" if spec is None else len(matches),
                "mapping_basis": "" if spec is None else f"EID{spec[0]} {spec[1]} contains {spec[2]} on {spec[3]}",
                "review_comment": comment,
            })
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    (ROOT / "outputs/independent_reference_mapping_sha256.txt").write_text(
        digest + "  05_INDEPENDENT_AUTHOR_PLAN_RAW_MAPPING.csv\n")
    print(json.dumps({"plan_rows": len(rows) - 1, "mapping_sha256": digest}))
    db.close()


if __name__ == "__main__":
    main()
