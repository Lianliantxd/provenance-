"""Twenty bounded checks of the frozen raw-log qualification artifacts."""

from __future__ import annotations

import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sqlite3
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ResearchSafeguards(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.contract = json.loads((ROOT / "02_PRE_REGISTERED_POI_AND_REFERENCE_CONTRACT.json").read_text())
        cls.inv = json.loads((ROOT / "outputs/archive_inventory.json").read_text())
        cls.summary = json.loads((ROOT / "outputs/event_type_and_host_counts.json").read_text())
        cls.result = json.loads((ROOT / "outputs/b_only_candidates.json").read_text())
        with (ROOT / "05_INDEPENDENT_AUTHOR_PLAN_RAW_MAPPING.csv").open() as stream:
            cls.mapping = list(csv.DictReader(stream))
        cls.db = sqlite3.connect(ROOT / "outputs/events.sqlite")

    @classmethod
    def tearDownClass(cls) -> None:
        cls.db.close()

    def test_01_official_archive_identity(self) -> None:
        self.assertEqual(self.inv["sha256"], self.contract["raw_archive_sha256"])
        self.assertEqual(self.inv["official_blob_sha1"], "7352679a173ec0310f9d0ed587782545182dd394")

    def test_02_compressed_and_uncompressed_distinct(self) -> None:
        self.assertEqual(self.inv["size_bytes"], 13944973)
        self.assertEqual(self.inv["total_uncompressed_bytes"], 385334029)

    def test_03_archive_guard_and_crc(self) -> None:
        with zipfile.ZipFile(ROOT / self.contract["archive_relative_path"]) as zf:
            self.assertIsNone(zf.testzip())
            self.assertEqual(len(zf.infolist()), 1)
            self.assertFalse(zf.infolist()[0].flag_bits & 1)
            self.assertNotIn("..", Path(zf.infolist()[0].filename).parts)

    def test_04_raw_and_derived_cases_separate(self) -> None:
        self.assertIn("Security-Datasets", self.contract["official_repository"])
        self.assertNotIn("DiagChain", self.inv["local_path"])

    def test_05_full_background_parsed(self) -> None:
        self.assertEqual(self.summary["counts"]["lines"], 196081)
        self.assertEqual(self.summary["counts"]["valid_json_events"], 196081)
        self.assertEqual(self.summary["parse_errors"], {})

    def test_06_sysmon_provider_and_channel(self) -> None:
        self.assertEqual(self.summary["counts"]["sysmon_events"], 143884)
        self.assertEqual(self.db.execute("SELECT count(*) FROM events WHERE provider!='Microsoft-Windows-Sysmon' OR channel!='Microsoft-Windows-Sysmon/Operational'").fetchone()[0], 0)

    def test_07_event_types_distinct(self) -> None:
        self.assertEqual([self.db.execute("SELECT count(*) FROM events WHERE eid=?", (i,)).fetchone()[0] for i in (1, 3, 11)], [447, 1229, 1649])

    def test_08_eid10_not_parent_edge(self) -> None:
        self.assertEqual(self.db.execute("SELECT count(*) FROM events WHERE eid=10").fetchone()[0], 0)
        self.assertTrue(all(edge["grade"] == "SENSOR_PROCESS_CREATE" for edge in self.result["creation_edges"]))

    def test_09_utc_is_parsed_not_eventtime_sorted(self) -> None:
        self.assertIn("+00:00", self.summary["time_min_utc"])
        self.assertLess(datetime.fromisoformat(self.summary["time_min_utc"]), datetime.fromisoformat(self.summary["time_max_utc"]))

    def test_10_guid_is_host_scoped(self) -> None:
        count = self.db.execute("SELECT count(DISTINCT host||'|'||guid) FROM events WHERE eid=1 AND guid IS NOT NULL").fetchone()[0]
        self.assertEqual(count, 446)

    def test_11_unobserved_parent_not_fabricated(self) -> None:
        self.assertEqual(self.result["terminal_condition"], "PARENT_REFERENCED_NOT_OBSERVED")
        self.assertFalse(self.result["processes_downstream_to_upstream"][-1]["creation_observed"])

    def test_12_parent_child_time_consistent(self) -> None:
        self.assertTrue(all(edge["time_consistent"] for edge in self.result["creation_edges"]))
        self.assertEqual(self.db.execute("SELECT count(*) FROM events c JOIN events p ON c.host=p.host AND c.parent_guid=p.guid AND p.eid=1 WHERE c.eid=1 AND p.ts>c.ts").fetchone()[0], 0)

    def test_13_b_rule_and_late_window(self) -> None:
        b = self.result["seed"]
        self.assertEqual(b["seed_type"], "RULE_GENERATED_INVESTIGATION_SEED")
        self.assertEqual(b["selection_score"], 3)
        self.assertGreaterEqual(b["ts"], self.summary["late_midpoint_utc"])

    def test_14_b_unique_locator(self) -> None:
        b = self.result["seed"]
        self.assertEqual(b["idx"], 137249)
        self.assertEqual(self.db.execute("SELECT count(*) FROM events WHERE idx=?", (b["idx"],)).fetchone()[0], 1)

    def test_15_b_record_hash_replays(self) -> None:
        b = self.result["seed"]
        with zipfile.ZipFile(ROOT / self.contract["archive_relative_path"]) as zf, zf.open(self.contract["zip_member"]) as stream:
            record = next(line for i, line in enumerate(stream, 1) if i == b["idx"])
        canonical = json.dumps(json.loads(record), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.assertEqual(hashlib.sha256(canonical.encode()).hexdigest(), b["canonical_sha256"])

    def test_16_contract_and_result_freeze(self) -> None:
        self.assertEqual(digest(ROOT / "02_PRE_REGISTERED_POI_AND_REFERENCE_CONTRACT.json"), (ROOT / "outputs/poi_contract_sha256.txt").read_text().split()[0])
        self.assertEqual(digest(ROOT / "outputs/b_only_candidates.json"), (ROOT / "outputs/b_only_candidates_sha256.txt").read_text().split()[0])

    def test_17_reference_frozen_after_b(self) -> None:
        logs = [json.loads(line) for line in (ROOT / "outputs/execution_log.jsonl").read_text().splitlines()]
        self.assertLess(datetime.fromisoformat(logs[0]["utc"]), datetime.fromisoformat(logs[1]["utc"]))
        self.assertEqual(logs[0]["reference_files_read"], 0)

    def test_18_all_day1_plan_rows_accounted_for(self) -> None:
        self.assertEqual(len(self.mapping), 31)
        self.assertEqual({int(row["source_row"]) for row in self.mapping}, set(range(2, 33)))

    def test_19_reference_and_path_disjoint(self) -> None:
        path = {(p["host"], p["guid"]) for p in self.result["processes_downstream_to_upstream"]}
        for row in self.mapping:
            for ref in json.loads(row["raw_record_refs"]):
                self.assertNotIn((ref["host"], ref["guid"]), path)

    def test_20_resource_and_side_effect_contract(self) -> None:
        limits = self.contract["resource_limits"]
        self.assertEqual((limits["new_model_calls"], limits["server_writes"], limits["github_pushes"]), (0, 0, 0))
        self.assertLess(self.inv["total_uncompressed_bytes"], limits["aggregate_uncompressed_input_max_mib"] * 1024 * 1024)


if __name__ == "__main__":
    unittest.main()
