# Frozen B-only source trace

`B_ONLY_TRACER` read only the frozen policy, `outputs/tracer_visible/poi_public.json` and the full-background SQLite index, through fixed paths. It did not read the XLSX, MITRE README, Day 1 map, candidate map or private references. It ran once after a source-code typo was corrected before any prediction artifact existed. Frozen prediction SHA-256: `a90193f8f3b342f58e96fb7737c2816357cf468c3a109bbd1497d11604d151f3`. Cost: 3 search states; 2 observed process instances; 2 same-process file operations as context; 1 unresolved parent reference. No budget was exhausted.

The only verified upstream creation edges are:

1. SCRANTON `wsmprovhost.exe` `{ac2fda3f-2cdd-5ead-6203-000000000400}` → `net.exe` `{ac2fda3f-2cdd-5ead-6303-000000000400}`. Evidence is child EID1 at member line **528,390**, EventRecordID 343984, UTC 08:18:37.619, raw SHA-256 `a61028a333e57e82ecf33ede9a9d9d5baf8ba599a170cc3f279d02f52df4f4fb`.
2. An earlier SCRANTON parent GUID `{ac2fda3f-1943-5ead-0e00-000000000400}` → `wsmprovhost.exe` `{ac2fda3f-2cdd-5ead-6203-000000000400}`. Evidence is child EID1 at line **527,958**, EventRecordID 343878, UTC 08:18:37.350, raw SHA-256 `45e9ed5c5d5094918e99f26592c431a72200addb821729552828b45762641ef5`. No earlier EID1 for that parent GUID was observed, so its process instance/origin is unresolved.

Two EID11 records at lines 528,311 and 528,314 belong to the `wsmprovhost.exe` GUID before B. They are same-process context and do not prove content handoff to `net.exe`. The B-only result has no verified cross-host, file-read or network receiver edge. It cannot connect B to the independently mapped UTICA operations from rows 21, 28, 29 or 34. The fact that remote session tooling and account creation appear in the author narrative does not fill the missing system-audit relationship. Full locators and types are in `outputs/tracer_predictions/b_only_paths.json`.

The immediate parent is a useful investigation lead, not a validated attack origin. No shared `System`/`services.exe` ancestor, same host, IP, path or time ordering was promoted to an attack-causal edge.
