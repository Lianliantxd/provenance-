# Evidence casebook and failure analysis

The posthoc evaluator verified 8 distinct source JSON lines directly in the same fixed Day 2 ZIP against stored raw-line SHA-256: B, four private reference events, one observed parent creation event and two same-process context events. Every claimed sensor creation edge is backed by the child's EID1 and same-host GUID fields. The reference events are real and earlier than B, but **0 of 4** lie on the B-only legal lineage; Returned@5 on that lineage is **0**. Only B is confirmed attack-related on the returned lineage without extra reference interpretation. No two attack-related instances with a proven source-to-B path are established.

Failure codes: `REFERENCE_NOT_UPSTREAM`, `NO_LEGAL_CROSS_ENTITY_PATH`, `PARENT_REFERENCED_NOT_OBSERVED`. The non-Sysmon operation-time/ingestion-time mismatch requires `TIME_SEMANTICS_MIXED_IN_NON_SYSMON_RECORDS`; the human viewing order deviation requires `PROCEDURAL_TIMING_DEVIATION`. The target workbook is a plan, and most rows were not uniquely raw-mapped in this targeted audit. This is a visibility/task-qualification failure, not a claim that an attack step did not occur.

There is no independent ground truth for every causal content-transfer edge or the global attacker root. Therefore `CausalEdgePrecision`, `CausalEdgeRecall`, `CausalEdgeF1`, `FullCausalAttackChainAccuracy` and `RootAttributionAccuracy` are all **NA**. The result cannot measure a proposed algorithm's improvement.

All published command/action summaries are shortened; original command lines, account secrets, raw ZIP and full SQLite index remain local and are excluded from the sync package. See `outputs/evaluator_only/replayed_evidence.json`, `outputs/posthoc_evaluation.json` and `05_POSTHOC_ATTACK_AND_PATH_QUALIFICATION.csv`.
