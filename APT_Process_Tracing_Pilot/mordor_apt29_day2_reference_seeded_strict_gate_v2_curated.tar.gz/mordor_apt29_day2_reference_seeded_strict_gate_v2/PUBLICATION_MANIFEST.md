# Curated synchronization manifest

This archive publishes the Day 2 qualification's code, tests, frozen policy and hashes, safe event locators, private-reference CSV after evaluation, path result and negative decision. It excludes the original ZIP, official XLSX/README copies and the full raw SQLite index. Those excluded files contain raw commands, account or network details and remain local. Reproduction requires independently obtaining the exact fixed-commit official ZIP and XLSX identified in the gate report.

The attached research prompt set `server_writes=0` and `auto_github_push=false`. The user's direct standing instruction in this chat requires syncing to the server and pushing GitHub every round, so this curated archive is synchronized under that higher-priority authorization. This changes publication handling only; it does not alter B, private reference selection, prediction or evaluation.

Case: `OTRF_MORDOR_APT29_DAY2_REFERENCE_SEEDED_V1`. Result: `DAY2_NO_LEGAL_ATTACK_SOURCE_PATH + METHOD_GAP_NOT_TESTED`. SHA-256 of each included file is in `outputs/SHA256SUMS.txt`.
