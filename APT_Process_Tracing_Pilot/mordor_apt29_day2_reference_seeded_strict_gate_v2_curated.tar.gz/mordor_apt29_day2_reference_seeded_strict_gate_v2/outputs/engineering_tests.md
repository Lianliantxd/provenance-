# Engineering safeguards

Reproduction: `python3 -m unittest discover -s tests -v` from this directory; all 4 tests passed. Main commands: `python3 src/prepare.py`, `python3 src/raw_indexer.py`, `python3 src/reference_registrar.py`, `python3 src/b_only_tracer.py`, `python3 src/posthoc_evaluator.py`. Frozen steps cannot be rerun in place; use a fresh independent directory for replication.

Additional protocol deviation: MITRE Day2 README was viewed while S2 process was running, after S1 policy freeze. This does not change the RAW_INDEXER file allowlist but violates the strict human-viewing stage order. The row 11.A classification label is also overstrong and treated as plan-only in the decision.

| # | Result | Evidence / caveat |
|---:|:---:|---|
| 1 | PASS | Fixed URL and local ZIP point to day2/apt29_evals_day2_manual.zip. |
| 2 | PASS | 43,033,041 bytes and Git blob SHA-1 verified; new ZIP SHA-256 measured. |
| 3 | PASS | Day1 ZIP hash/size excluded; case_id and B differ. |
| 4 | PASS | Single safe JSON ZIP member; full-stream CRC passed; 1.715 GB below 2.5 GiB. |
| 5 | PASS | No ZIP member, payload, macro or command was executed. |
| 6 | PASS | One-based raw JSON line index and RecordNumber held in separate columns. |
| 7 | PASS | Raw-line SHA-256 and canonical JSON SHA-256 held separately. |
| 8 | PASS | EID1/3/11/8/10 sensor meanings documented and only EID1 used for parent creation. |
| 9 | PASS | ProcessGuid queries are host scoped; PID never used as global identity. |
| 10 | PASS | Every claimed creation edge checks child EID1 and parent GUID; missing parent creation reported. |
| 11 | PASS | Sysmon UtcTime treated as UTC; non-Sysmon @timestamp ingestion caveat recorded; no cross-host clock claim. |
| 12 | PASS | No path/IP/host/time co-occurrence promoted to causal transfer. |
| 13 | PASS | Shared system ancestors never connect branches. |
| 14 | PASS | Index includes 587,286 events before reference mapping; no IOC prefilter. |
| 15 | PASS | Policy hash and file mtime precede B and prediction. |
| 16 | PASS | B is Day2 plan row 20.B matched to unique net.exe EID1; EID4720 is corroboration, not seed. |
| 17 | PASS | Candidate map sealed and hashed before B-only prediction. |
| 18 | PASS | Tracer has fixed input paths; source audit confirms no reference/plan file access. |
| 19 | PASS | 8 distinct claimed/reference raw lines replayed from same Day2 ZIP with SHA-256. |
| 20 | PASS | Registrar asserts unique eligible B before producing public seed; no-B branch would stop. |
| 21 | PASS | No B reselection and no prediction overwrite after negative result. |
| 22 | PASS | Independent causal edge GT absent; causal P/R/F1 all NA. |
| 23 | PASS | No model training, LLM/GPU call, agent innovation or performance comparison. |
| 24 | FAIL | Attached prompt forbids server writes/auto GitHub push; standing direct user instruction requires both every round and takes precedence. Curated sync is therefore explicitly outside this attached constraint. |
