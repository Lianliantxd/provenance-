"""Posthoc replay and comparison, executed only after frozen prediction exists."""
import csv,hashlib,json,sqlite3,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R/'outputs'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    prediction=O/'tracer_predictions/b_only_paths.json'; private=O/'evaluator_only/reference_private.csv'; public=O/'tracer_visible/poi_public.json'
    assert sha(prediction)==(O/'tracer_predictions/b_only_paths.sha256').read_text().strip()
    assert sha(private)==(O/'evaluator_only/reference_private.sha256').read_text().strip()
    assert sha(public)==(O/'tracer_visible/poi_public.sha256').read_text().strip()
    b=json.loads(public.read_text()); pred=json.loads(prediction.read_text()); refs=list(csv.DictReader(private.open()))
    db=sqlite3.connect(O/'raw_visible_index.sqlite');db.row_factory=sqlite3.Row
    requested={b['record_index_1based']:b['event_sha256']}
    for x in refs:requested[int(x['raw_index'])]=x['raw_sha256']
    for x in pred['lineage']:requested[x['idx']]=x['raw_sha256']
    for x in pred['context_operations']:requested[x['record_index_1based']]=x['raw_sha256']
    replay=[];zpath=R/'inputs/apt29_evals_day2_manual.zip'
    with zipfile.ZipFile(zpath) as z:
        member=z.infolist()[0]
        with z.open(member) as stream:
            for idx,line in enumerate(stream,1):
                if idx in requested:
                    actual=hashlib.sha256(line).hexdigest(); assert actual==requested[idx]
                    d=json.loads(line)
                    replay.append({'idx':idx,'member':member.filename,'raw_sha256':actual,'event_id':d.get('EventID'),'record_number':d.get('RecordNumber'),'hostname':d.get('Hostname'),'utc_time':d.get('UtcTime'),'ingest_timestamp':d.get('@timestamp')})
                if idx>=max(requested):break
    assert len(replay)==len(requested)
    (O/'evaluator_only/replayed_evidence.json').write_text(json.dumps(replay,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    lineage_ids={x['idx'] for x in pred['lineage']}; context_ids={x['record_index_1based'] for x in pred['context_operations']}
    rows=[]
    for x in refs:
        rid=int(x['raw_index']); status='LEGAL_LINEAGE' if rid in lineage_ids else 'CONTEXT_ONLY' if rid in context_ids else 'NOT_LEGALLY_REACHED'
        rows.append({'reference_step':x['step'],'worksheet_row':x['row'],'raw_index':rid,'host':x['host'],'event_id':x['eid'],'raw_replay':'PASS','legal_reachability':status,'returned_at_5':status=='LEGAL_LINEAGE','failure':'REFERENCE_NOT_UPSTREAM' if status=='NOT_LEGALLY_REACHED' else ''})
    with (R/'05_POSTHOC_ATTACK_AND_PATH_QUALIFICATION.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    status='DAY2_NO_LEGAL_ATTACK_SOURCE_PATH'
    # Replayed B is real. The observed creator chain stops at missing parent;
    # none of the independent earlier operations are a legal upstream hop.
    eval={'case_id':b['case_id'],'task_state':status,'method_state':'METHOD_GAP_NOT_TESTED','B_verified':True,'B_reference_seeded':True,'earlier_unique_reference_count':len(refs),'reference_presence':len(refs),'legal_reachability':sum(x['legal_reachability']=='LEGAL_LINEAGE' for x in rows),'returned_at_5':sum(x['returned_at_5'] for x in rows),'attack_related_process_instances_on_legal_path':1,'valid_process_create_edges':sum(x['relation']=='SENSOR_PROCESS_CREATE' for x in pred['hops']),'causal_edge_precision':'NA','causal_edge_recall':'NA','causal_edge_f1':'NA','full_causal_attack_chain_accuracy':'NA','root_attribution_accuracy':'NA','source_candidate':'wsmprovhost process is an immediate observed parent, not an independently validated attack origin','failure_codes':['REFERENCE_NOT_UPSTREAM','NO_LEGAL_CROSS_ENTITY_PATH','PARENT_REFERENCED_NOT_OBSERVED','TIME_SEMANTICS_MIXED_IN_NON_SYSMON_RECORDS','PROCEDURAL_TIMING_DEVIATION'],'raw_replay_count':len(replay),'prediction_sha256':sha(prediction),'private_reference_sha256':sha(private),'rows':rows}
    (O/'posthoc_evaluation.json').write_text(json.dumps(eval,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:eval[k] for k in ['task_state','earlier_unique_reference_count','legal_reachability','raw_replay_count','failure_codes']}))
if __name__=='__main__':main()
