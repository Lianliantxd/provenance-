"""Identity gate and pre-registration. Does not read attack plans."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT / "inputs/apt29_evals_day2_manual.zip"
OUT = ROOT / "outputs"
COMMIT = "d9d40ef123d2c87d5d3df28c96bcab4f0faccc87"
MEMBER = "apt29_evals_day2_manual_2020-05-02035409.json"
CASE = "OTRF_MORDOR_APT29_DAY2_REFERENCE_SEEDED_V1"

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n")

def main():
    size = ZIP.stat().st_size
    sha = hashlib.sha256()
    blob = hashlib.sha1(b"blob " + str(size).encode() + b"\0")
    with ZIP.open("rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            sha.update(chunk); blob.update(chunk)
    assert size == 43033041 and blob.hexdigest() == "15e1e9d2d88a729b832c6430fa285c3e87bb70e4"
    assert sha.hexdigest() != "98a073140860560d70080ace9142961be4f64b4862bae892d62d0f254d0fdbe5"
    with zipfile.ZipFile(ZIP) as z:
        items = z.infolist()
        assert len(items) == 1
        i = items[0]
        assert i.filename == MEMBER and not (i.flag_bits & 1)
        assert not i.is_dir() and not i.filename.startswith("/") and ".." not in Path(i.filename).parts
        assert i.filename.endswith(".json") and i.file_size <= 2.5 * 1024**3
        inventory = [{"member":i.filename,"uncompressed_bytes":i.file_size,"compressed_bytes":i.compress_size,"crc32":f"{i.CRC:08x}","compression_ratio":round(i.file_size/i.compress_size,2),"encrypted":False}]
        with z.open(i) as f:
            sample = f.readline()
        sample_obj = json.loads(sample)
        assert isinstance(sample_obj, dict) and "EventID" in sample_obj
    free = shutil.disk_usage(ROOT).free
    assert free >= 10 * 1024**3
    identity = {"case_id":CASE,"source_commit":COMMIT,"source_url":f"https://raw.githubusercontent.com/OTRF/Security-Datasets/{COMMIT}/datasets/compound/apt29/day2/apt29_evals_day2_manual.zip","local_path":str(ZIP.resolve()),"compressed_bytes":size,"sha256":sha.hexdigest(),"git_blob_sha1":blob.hexdigest(),"zip_member":MEMBER,"available_disk_bytes":free,"gate":"PASS","day1_zip_excluded":True}
    write(OUT/"day2_source_identity.json",identity)
    write(OUT/"day2_zip_inventory.json",inventory)
    policy = {"case_id":CASE,"source_commit":COMMIT,"archive_sha256":sha.hexdigest(),"plan_source_and_revision":{"path":f"datasets/compound/apt29/emulationplans/apt29.xlsx","source_commit":COMMIT,"mitre_day2_readme_revision":"record_on_first_read"},"reader_allowlists_and_forbidden_files":{"RAW_INDEXER":["inputs/apt29_evals_day2_manual.zip","01_FROZEN_SEED_AND_QUERY_POLICY.json"],"REFERENCE_REGISTRAR":["inputs/apt29.xlsx","outputs/raw_visible_index.sqlite","01_FROZEN_SEED_AND_QUERY_POLICY.json"],"B_ONLY_TRACER":["outputs/tracer_visible/poi_public.json","outputs/raw_visible_index.sqlite","01_FROZEN_SEED_AND_QUERY_POLICY.json"],"POSTHOC_EVALUATOR":["outputs/evaluator_only/reference_private.csv","outputs/evaluator_only/selection_audit.json","outputs/tracer_predictions/b_only_paths.json","outputs/raw_visible_index.sqlite"],"forbidden_to_tracer":["apt29.xlsx","reference_private.csv","selection_audit.json","Day1 results","DiagChain GT","MITRE plan"]},"reference_operation_match_requirements":"Day2 author-reported execution plus matching host, operation, process/object and time/order in unique replayable raw event; ambiguous candidates remain ambiguous","attack_execution_vs_plan_only_policy":"Exclude preparation and planned-only rows as B and hidden executed references","late_stage_ranking_rule_and_tie_break":"Traverse Day2 author execution rows in reverse worksheet row order; first uniquely mapped later action wins; within row prefer concrete directional network/file operation, then process creation, then other single audit operation; ties earliest UTC then lexicographic member/index; never inspect ancestors for selection","permitted_POI_event_types":[1,3,11,8,10],"host_clock_identity_validation":"Use UTC parsed from raw UtcTime, scope ProcessGuid to Hostname, never infer cross-host clock calibration or join by PID alone","hidden_upstream_selection_and_mapping_policy":"Before trace, preserve all independently uniquely raw-mapped earlier executed operations; require at least two distinct; do not select by predicted path","trace_operation_edge_types_and_direction":["SENSOR_PROCESS_CREATE parent-to-child using child EID1 ParentProcessGuid","SENSOR_NETWORK_OPERATION initiating process-to-flow only","SENSOR_FILE_OPERATION process-to-created-file only","SENSOR_PROCESS_ACCESS source-to-target only when both GUIDs validated","OBSERVED_SAME_PROCESS_CONTEXT context only, not causal handoff","UNRESOLVED_GAP when read/receiver absent"],"max_hops":12,"max_unique_events_returned":256,"max_search_states":50000,"max_output_paths":5,"max_local_resource_use":{"max_working_memory_bytes":1610612736,"max_local_peak_disk_bytes":5368709120,"max_uncompressed_zip_members_bytes":2684354560,"hosted_llm_calls":0,"gpu_runs":0},"one_primary_B_only":True,"allow_posthoc_change_B":False,"seed_type":"REFERENCE_SEEDED","method_status":"METHOD_GAP_NOT_TESTED","separation":"PROCEDURALLY_SEPARATED_NOT_BLINDED"}
    pp=ROOT/"01_FROZEN_SEED_AND_QUERY_POLICY.json"
    assert not pp.exists(), "policy already frozen; do not overwrite"
    write(pp,policy)
    (OUT/"policy.sha256").write_text(hashlib.sha256(pp.read_bytes()).hexdigest()+"\n")
    (ROOT/"00_DAY2_IDENTITY_AND_ASSET_GATE.md").write_text(f"# Day 2 identity gate\n\nPASS. Fixed commit `{COMMIT}`; ZIP `{ZIP.resolve()}`; size {size}; SHA-256 `{sha.hexdigest()}`; Git blob SHA-1 `{blob.hexdigest()}`. One safe JSON member `{MEMBER}`, {i.file_size} uncompressed bytes; central-directory CRC `{i.CRC:08x}`. CRC will be verified by complete streaming in S2. Disk free {free} bytes. Day 1 ZIP and B are excluded.\n")
    print(json.dumps({"identity":identity,"policy_sha256":hashlib.sha256(pp.read_bytes()).hexdigest()}))

if __name__ == "__main__": main()
