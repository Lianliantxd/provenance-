"""Label-blind streaming Day 2 index; reads only official ZIP and frozen policy."""
import collections
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
POL=ROOT/'01_FROZEN_SEED_AND_QUERY_POLICY.json'
ZIP=ROOT/'inputs/apt29_evals_day2_manual.zip'
OUT=ROOT/'outputs'
EXPECTED_POLICY='23fc2c6d6cb1f91343577e0bb12afaf4147a40fc6f9005fd98bcc246b84d6077'

def val(d,*keys):
    for k in keys:
        x=d.get(k)
        if x is not None and x!='': return str(x)
    return None

def utc(v):
    if not v: return None
    try:
        x=datetime.fromisoformat(str(v).strip().replace('Z','+00:00'))
        if x.tzinfo is None: x=x.replace(tzinfo=timezone.utc)
        return x.astimezone(timezone.utc).isoformat(timespec='milliseconds')
    except (ValueError,TypeError): return None

def main():
    assert hashlib.sha256(POL.read_bytes()).hexdigest()==EXPECTED_POLICY
    pol=json.loads(POL.read_text())
    assert pol['archive_sha256']==json.loads((OUT/'day2_source_identity.json').read_text())['sha256']
    dbfile=OUT/'raw_visible_index.sqlite'
    assert not dbfile.exists(), 'existing index: audit before resuming'
    db=sqlite3.connect(dbfile)
    db.execute('PRAGMA journal_mode=DELETE')
    db.execute('CREATE TABLE events(idx INTEGER PRIMARY KEY, member TEXT NOT NULL, raw_sha TEXT NOT NULL, canonical_sha TEXT NOT NULL, eid INTEGER, provider TEXT, channel TEXT, record_number TEXT, ts TEXT, host TEXT, user TEXT, guid TEXT, parent_guid TEXT, pid TEXT, parent_pid TEXT, image TEXT, parent_image TEXT, command TEXT, source_ip TEXT, source_port TEXT, dest_ip TEXT, dest_port TEXT, protocol TEXT, target_file TEXT, target_object TEXT, source_guid TEXT, target_guid TEXT)')
    counts=collections.Counter(); hosts=collections.Counter(); providers=collections.Counter(); channels=collections.Counter(); eids=collections.Counter(); cover=collections.Counter(); errors=collections.Counter(); first=None; last=None; samples={}; seen=set(); dup=0
    with zipfile.ZipFile(ZIP) as z:
        item=z.infolist()[0]
        assert item.filename==json.loads((OUT/'day2_source_identity.json').read_text())['zip_member']
        with z.open(item) as stream:
            for idx,raw in enumerate(stream,1):
                counts['physical_lines']+=1
                try:
                    d=json.loads(raw)
                    if not isinstance(d,dict): raise ValueError('not object')
                    eid=int(d['EventID'])
                except (ValueError,KeyError,TypeError,json.JSONDecodeError) as e:
                    errors[type(e).__name__]+=1; continue
                counts['valid_events']+=1
                host=val(d,'Hostname','Computer')
                provider=val(d,'SourceName','ProviderName')
                channel=val(d,'Channel')
                ts=utc(val(d,'UtcTime','TimeCreated','@timestamp'))
                if not ts: errors['bad_time']+=1
                else:
                    first=min(first,ts) if first else ts; last=max(last,ts) if last else ts
                hosts[host or 'MISSING']+=1; providers[provider or 'MISSING']+=1; channels[channel or 'MISSING']+=1; eids[str(eid)]+=1
                keys=['ProcessGuid','ParentProcessGuid','ProcessId','ParentProcessId','RecordNumber','Image','CommandLine','DestinationIp','DestinationPort','TargetFilename','SourceProcessGUID','TargetProcessGUID']
                for k in keys:
                    if d.get(k) not in (None,''): cover[k]+=1
                if str(eid) not in samples: samples[str(eid)]={'index':idx,'keys':sorted(d.keys()),'host':host,'provider':provider,'channel':channel}
                raw_sha=hashlib.sha256(raw).hexdigest()
                canonical_sha=hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
                if raw_sha in seen: dup+=1
                if len(seen)<100000: seen.add(raw_sha)
                row=(idx,item.filename,raw_sha,canonical_sha,eid,provider,channel,val(d,'RecordNumber','EventRecordID'),ts,host,val(d,'User','AccountName'),val(d,'ProcessGuid'),val(d,'ParentProcessGuid'),val(d,'ProcessId'),val(d,'ParentProcessId'),val(d,'Image'),val(d,'ParentImage'),val(d,'CommandLine'),val(d,'SourceIp'),val(d,'SourcePort'),val(d,'DestinationIp'),val(d,'DestinationPort'),val(d,'Protocol'),val(d,'TargetFilename'),val(d,'TargetObject'),val(d,'SourceProcessGUID','SourceProcessGuid'),val(d,'TargetProcessGUID','TargetProcessGuid'))
                db.execute('INSERT INTO events VALUES ('+','.join('?'*len(row))+')',row)
                if idx%10000==0: db.commit()
    db.commit()
    db.execute('CREATE INDEX by_guid ON events(host,guid,ts)')
    db.execute('CREATE INDEX by_parent ON events(host,parent_guid,ts)')
    db.execute('CREATE INDEX by_eid_time ON events(eid,ts)')
    db.execute('CREATE INDEX by_record ON events(host,record_number)')
    db.commit()
    # Integrity and sample replay: ZIP CRC is checked when stream reaches EOF.
    db.execute('PRAGMA integrity_check')
    replay=[]
    for eventid in ('1','3','11','8','10'):
        if eventid in samples:
            ix=samples[eventid]['index']; r=db.execute('SELECT idx,member,raw_sha,canonical_sha,eid,record_number,host,ts FROM events WHERE idx=?',(ix,)).fetchone()
            replay.append(dict(zip(['idx','member','raw_sha256','canonical_sha256','eid','record_number','host','utc'],r)))
    summary={'case_id':pol['case_id'],'archive_sha256':pol['archive_sha256'],'zip_member':item.filename,'zip_crc32_verified_by_complete_stream':True,'uncompressed_bytes':item.file_size,'counts':dict(counts),'hosts':dict(hosts),'providers':dict(providers),'channels':dict(channels),'event_ids':dict(eids),'field_coverage':dict(cover),'errors':dict(errors),'time_first_utc':first,'time_last_utc':last,'schema_samples':samples,'duplicate_raw_sha_sampled_first_100k':dup,'index_bytes':dbfile.stat().st_size}
    (OUT/'event_host_time_summary.json').write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    (OUT/'raw_locator_replay.json').write_text(json.dumps(replay,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'valid_events':counts['valid_events'],'hosts':dict(hosts),'eid1':eids['1'],'eid3':eids['3'],'eid11':eids['11'],'first':first,'last':last,'index_bytes':dbfile.stat().st_size}))
    db.close()

if __name__=='__main__': main()
