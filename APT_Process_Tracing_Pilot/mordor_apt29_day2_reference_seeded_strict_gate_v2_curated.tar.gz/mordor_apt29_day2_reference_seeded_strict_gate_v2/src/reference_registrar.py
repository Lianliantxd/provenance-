"""Reference-only registrar. Never reads tracer outputs or Day 1 maps."""
import csv,hashlib,json,posixpath,re,sqlite3,zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

R=Path(__file__).resolve().parents[1]; O=R/'outputs'; N={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
POL=json.loads((R/'01_FROZEN_SEED_AND_QUERY_POLICY.json').read_text())
assert hashlib.sha256((R/'01_FROZEN_SEED_AND_QUERY_POLICY.json').read_bytes()).hexdigest()=='23fc2c6d6cb1f91343577e0bb12afaf4147a40fc6f9005fd98bcc246b84d6077'
assert not (O/'tracer_predictions').exists(), 'reference mapping must precede tracing'

def workbook():
    z=zipfile.ZipFile(R/'inputs/apt29.xlsx'); ss=[''.join(t.text or '' for t in e.findall('.//m:t',N)) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',N)]
    w=ET.fromstring(z.read('xl/workbook.xml')); rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels')); rr={x.attrib['Id']:x.attrib['Target'] for x in rel}; sheets={};
    for s in w.findall('m:sheets/m:sheet',N):
        target=rr[s.attrib['{'+N['r']+'}id']]; path=target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)
        root=ET.fromstring(z.read(path)); rows=[]
        for row in root.findall('.//m:sheetData/m:row',N):
            cells={}
            for c in row.findall('m:c',N):
                v=c.find('m:v',N); inline=c.find('m:is',N)
                value=v.text if v is not None else ''.join(t.text or '' for t in inline.findall('.//m:t',N)) if inline is not None else ''
                if c.attrib.get('t')=='s' and value: value=ss[int(value)]
                cells[re.match('[A-Z]+',c.attrib['r']).group()]=value or ''
            rows.append((int(row.attrib['r']),cells))
        sheets[s.attrib['name']]=rows
    return sheets

def rows(db,sql,params=()):
    return [dict(r) for r in db.execute(sql,params)]

def safe_event(e):
    return {k:e[k] for k in ['idx','member','raw_sha','canonical_sha','eid','provider','channel','record_number','ts','host','guid','parent_guid','image','parent_image','target_file']}

def main():
    sheets=workbook(); assert 'day2' in sheets
    db=sqlite3.connect(O/'raw_visible_index.sqlite'); db.row_factory=sqlite3.Row
    # Narrow, independently stated raw signatures. Unmatched rows stay plan-only;
    # broad image/path coincidence never becomes an execution match.
    rules={
        '11.A':('UTICA','eid=1 AND (lower(command) LIKE ? OR lower(command) LIKE ?)',['%37486-the-shocking%','%schemas.ps1%']),
        '14.A':('UTICA','eid=1 AND lower(command) LIKE ?',['%sdclt%']),
        '14.B':('UTICA','eid=11 AND lower(target_file) LIKE ?',['%\\m.exe']),
        '17.B':('UTICA','eid=11 AND lower(target_file) LIKE ?',['%windowsparentalcontrolmigration\\mitre-attack-evals.html']),
        '17.C':('UTICA','eid=11 AND lower(target_file) LIKE ?',['%windowsparentalcontrolmigration.tmp']),
        '18.A':('UTICA','eid=1 AND lower(command) LIKE ?',['%davclnt.dll,davsetcookie%d.docs.live.net%']),
        '20.A':('UTICA','eid=1 AND lower(image) LIKE ? AND lower(command) LIKE ?',['%\\rundll32.exe','%kxwn.lock%']),
        '20.B':('SCRANTON','eid=1 AND lower(image) LIKE ? AND lower(command) LIKE ?',['%\\net.exe','%user /add toby%']),
    }
    mapping=[]
    for rn,c in sheets['day2'][1:]:
        step=c.get('C','').strip(); stage=c.get('A','').strip(); desc=' '.join(c.get('D','').split())[:300]
        item={'worksheet':'day2','row':rn,'step':step,'stage':stage,'action_summary':desc,'target_endpoint':c.get('H',''),'status':'PLAN_ONLY','candidate_count':0,'candidates':[],'basis':'worksheet description alone is a plan, not an execution record','ambiguity':None}
        if step=='0': item['basis']='preparation/setup row, excluded from attack execution reference'
        elif step in rules:
            host,where,params=rules[step]
            match=rows(db,'SELECT * FROM events WHERE host LIKE ? AND '+where, (host+'%',*params))
            item['candidate_count']=len(match); item['candidates']=[safe_event(e) for e in match[:20]]
            item['status']='RAW_OPERATION_UNIQUELY_MATCHED' if len(match)==1 else 'RAW_OPERATION_MULTIPLE_CANDIDATES' if len(match)>1 else 'AUTHOR_REPORTED_EXECUTED_NOT_RAW_MATCHED'
            item['basis']='host plus narrow operation/object or exact process command signature; proves only the logged operation'
            if len(match)>1: item['ambiguity']='multiple raw events for one plan row; no unique operation-level match'
        mapping.append(item)
    mpath=O/'evaluator_only/candidate_map.json'; mpath.parent.mkdir(parents=True,exist_ok=True)
    assert not mpath.exists()
    mpath.write_text(json.dumps({'case_id':POL['case_id'],'source_workbook_sha256':hashlib.sha256((R/'inputs/apt29.xlsx').read_bytes()).hexdigest(),'worksheets':{k:len(v)-1 for k,v in sheets.items()},'rows':mapping},ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    mh=hashlib.sha256(mpath.read_bytes()).hexdigest(); (O/'evaluator_only/candidate_map.sha256').write_text(mh+'\n')
    # Ranking is reverse author row order, first unique permitted B.
    eligible=[x for x in reversed(mapping) if x['status']=='RAW_OPERATION_UNIQUELY_MATCHED' and x['candidates'][0]['eid'] in POL['permitted_POI_event_types']]
    assert eligible, 'REFERENCE_SEED_NOT_VERIFIED'
    picked=eligible[0]; b=picked['candidates'][0]
    assert picked['step']=='20.B' and b['eid']==1, 'review Day2 selection, never substitute B'
    public={'case_id':POL['case_id'],'source_archive_sha256':POL['archive_sha256'],'seed_type':'REFERENCE_SEEDED','member':b['member'],'record_index_1based':b['idx'],'event_sha256':b['raw_sha'],'host':b['host'],'timestamp_utc':b['ts'],'provider':b['provider'],'event_id':b['eid'],'event_record_id':b['record_number'],'process_guid':b['guid'],'parent_process_guid':b['parent_guid'],'image':b['image']}
    ppath=O/'tracer_visible/poi_public.json'; ppath.parent.mkdir(parents=True,exist_ok=True); assert not ppath.exists(); ppath.write_text(json.dumps(public,sort_keys=True,ensure_ascii=False,indent=2)+'\n')
    (O/'tracer_visible/poi_public.sha256').write_text(hashlib.sha256(ppath.read_bytes()).hexdigest()+'\n')
    # All independently uniquely matched earlier actions, not chosen for reachability.
    refs=[(x,x['candidates'][0]) for x in mapping if x['status']=='RAW_OPERATION_UNIQUELY_MATCHED' and x['candidates'][0]['ts']<b['ts'] and x['row']<picked['row']]
    refsfile=O/'evaluator_only/reference_private.csv'; assert not refsfile.exists()
    with refsfile.open('w',newline='') as f:
        w=csv.writer(f); w.writerow(['worksheet','row','step','stage','raw_index','member','raw_sha256','host','utc','eid','event_record_id','process_guid','operation_summary'])
        for x,e in refs: w.writerow(['day2',x['row'],x['step'],x['stage'],e['idx'],e['member'],e['raw_sha'],e['host'],e['ts'],e['eid'],e['record_number'],e['guid'],x['action_summary']])
    (O/'evaluator_only/reference_private.sha256').write_text(hashlib.sha256(refsfile.read_bytes()).hexdigest()+'\n')
    audit={'case_id':POL['case_id'],'candidate_map_sha256':mh,'selected_step':picked['step'],'selected_row':picked['row'],'selected_raw_index':b['idx'],'selection_rule':'reverse worksheet row, first uniquely matched permitted B, independent of ancestor/path','earlier_unique_reference_count':len(refs),'earlier_unique_reference_rows':[x['row'] for x,_ in refs],'status_counts':{s:sum(x['status']==s for x in mapping) for s in sorted({x['status'] for x in mapping})},'procedural_separation':'PROCEDURALLY_SEPARATED_NOT_BLINDED','timing_deviation':'MITRE Day2 README viewed while S2 raw indexer process was running; policy already frozen and indexer allowlist excluded plan'}
    (O/'evaluator_only/selection_audit.json').write_text(json.dumps(audit,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'worksheets':{k:len(v)-1 for k,v in sheets.items()},'status_counts':audit['status_counts'],'B':public,'refs':audit['earlier_unique_reference_rows'],'candidate_map_sha256':mh,'poi_sha256':hashlib.sha256(ppath.read_bytes()).hexdigest()}))

if __name__=='__main__':main()
