import hashlib,json,sqlite3,unittest,zipfile
from pathlib import Path

R=Path(__file__).resolve().parents[1];O=R/'outputs'
class Day2GateTests(unittest.TestCase):
    def test_fixed_day2_identity(self):
        x=json.loads((O/'day2_source_identity.json').read_text())
        self.assertEqual(x['compressed_bytes'],43033041)
        self.assertEqual(x['git_blob_sha1'],'15e1e9d2d88a729b832c6430fa285c3e87bb70e4')
        self.assertNotEqual(x['sha256'],'98a073140860560d70080ace9142961be4f64b4862bae892d62d0f254d0fdbe5')
        self.assertIn('day2/',x['source_url'])
    def test_policy_precedes_B_and_prediction_is_frozen(self):
        pol=R/'01_FROZEN_SEED_AND_QUERY_POLICY.json'; poi=O/'tracer_visible/poi_public.json';pred=O/'tracer_predictions/b_only_paths.json'
        self.assertLess(pol.stat().st_mtime_ns,poi.stat().st_mtime_ns)
        self.assertLess(poi.stat().st_mtime_ns,pred.stat().st_mtime_ns)
        self.assertEqual(hashlib.sha256(pol.read_bytes()).hexdigest(),(O/'policy.sha256').read_text().strip())
        self.assertEqual(hashlib.sha256(pred.read_bytes()).hexdigest(),(O/'tracer_predictions/b_only_paths.sha256').read_text().strip())
    def test_every_claimed_process_edge_is_child_eid1(self):
        p=json.loads((O/'tracer_predictions/b_only_paths.json').read_text())
        d=sqlite3.connect(O/'raw_visible_index.sqlite');d.row_factory=sqlite3.Row
        for edge in p['hops']:
            if edge['relation']!='SENSOR_PROCESS_CREATE':continue
            e=d.execute('select * from events where idx=?',(edge['evidence']['record_index_1based'],)).fetchone()
            self.assertEqual((e['eid'],e['host'],e['guid'],e['parent_guid'],e['raw_sha']),(1,edge['host'],edge['child_guid'],edge['parent_guid'],edge['evidence']['raw_sha256']))
    def test_no_reference_in_tracer_or_false_handoff(self):
        source=(R/'src/b_only_tracer.py').read_text()
        for forbidden in ['apt29.xlsx','reference_private.csv','candidate_map.json','selection_audit.json','mitre_day2_README.md']:
            self.assertNotIn(forbidden,source)
        p=json.loads((O/'tracer_predictions/b_only_paths.json').read_text())
        self.assertFalse(p['cross_host_handoff_proven'])
        self.assertFalse(p['file_content_handoff_proven'])
        self.assertFalse(p['network_peer_handoff_proven'])
        self.assertTrue(all(not x['directional_handoff_proven'] for x in p['context_operations']))
if __name__=='__main__':unittest.main()
